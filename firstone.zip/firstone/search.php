<?php

session_start();

require_once("db.php");

$limit = 10;

if(isset($_GET["page"])) {
	$page = $_GET['page'];
} else {
	$page = 1;
}

$start_from = ($page-1) * $limit;


if(isset($_GET['filter']) && $_GET['filter']=='city') {

  $sql = "SELECT * FROM users WHERE city='$_GET[search]'";
  $result = $conn->query($sql);
  if($result->num_rows > 0) {
    while($row1 = $result->fetch_assoc()) {
      $sql1 = "SELECT * FROM users WHERE id_user>='$row1[id_user]' LIMIT $start_from, $limit";
                $result1 = $conn->query($sql1);
                if($result1->num_rows > 0) {
                  while($row = $result1->fetch_assoc()) 
                  {
               ?>

<div class="attachment-block clearfix">
					<div class="attachment-pushed">
					  <h4 class="attachment-heading"><a href="view-job-post.php?id=<?php echo $row['id_user']; ?>"><?php echo $row['jobs']; ?></a> <span class="attachment-heading pull-right">$<?php echo $row['payrate']; ?></span></h4>
					  <div class="attachment-text">
						  <div><strong><?php echo $row1['parentsfirstname']; ?> | <?php echo $row1['city']; ?> |  <?php echo $row['age']; ?> Years Old</strong></div>
					  </div>
					</div>
				  </div>

      <?php
        }
      }
    }
  }


} else {

  if(isset($_GET['filter'])) {

    $jobs = $_GET['search'];
    $location = $_GET['location'];
    $sql = "SELECT * FROM users WHERE jobs LIKE '%$jobs%' AND city LIKE '%$location%' ORDER BY RAND() LIMIT $start_from, $limit"; 
//echo $_GET['search'];
//echo $jobs;
//echo $_GET['location'];

//print_r($_GET);

  } else if(isset($_GET['filter']) && $_GET['filter']=='experience') {

    $sql = "SELECT * FROM users WHERE jobs>='$_GET[search]' LIMIT $start_from, $limit";

  }

  $result = $conn->query($sql);
  if($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
      $sql1 = "SELECT * FROM users WHERE id_user='$row[id_user]'";
                $result1 = $conn->query($sql1);
                if($result1->num_rows > 0) {
                  while($row1 = $result1->fetch_assoc()) 
                  {
               ?>

<div class="attachment-block clearfix">
					<div class="attachment-pushed">
					  <h4 class="attachment-heading"><a href="view-job-post.php?id=<?php echo $row['id_user']; ?>"><?php echo $row['jobs']; ?></a> <span class="attachment-heading pull-right">$<?php echo $row['payrate']; ?></span></h4>
					  <div class="attachment-text">
						  <div><strong><?php echo $row1['parentsfirstname']; ?> | <?php echo $row1['city']; ?> |  <?php echo $row['age']; ?> Years Old</strong></div>
					  </div>
					</div>
				  </div>

      <?php
        }
      }
    }
  }

}




$conn->close();