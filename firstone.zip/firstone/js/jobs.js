var checkList = document.getElementById('list1');
var jobs = document.getElementById('jobs');
        checkList.getElementsByClassName('anchor')[0].onclick = function (evt) {
            if (jobs.classList.contains('visible')){
                jobs.classList.remove('visible');
                jobs.style.display = "none";
            }
            
            else{
                jobs.classList.add('visible');
                jobs.style.display = "block";
            }
            
            
        }

        jobs.onblur = function(evt) {
            jobs.classList.remove('visible');
        }